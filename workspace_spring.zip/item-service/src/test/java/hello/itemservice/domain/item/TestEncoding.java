package hello.itemservice.domain.item;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class TestEncoding {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	void test() throws UnsupportedEncodingException  {
		
		 //StandardCharsets.EUC_KR
		
		String[] arr = {"가나다", "123", "abc", "가나다abc"};
		
		for (String str : arr) {
			System.out.println(str + ":" + detectEncoding(str));
			str.getBytes("euc-kr");
			
		}
		
		String[] arr2 = {"가나다", "123", "abc", "가나다abc"};
		
		for (String str : arr2) {
			System.out.println(str + ":" + detectEncoding(str));
			
		}		
		
	}

	
	public static String detectEncoding(String str) {
		
		String strLine = "abcde";

		for (int i = 0 ; i < strLine.length() ; i++) {
			if ((int)strLine.charAt(i) == 65533){
				return "euc-kr";
			}
		}
		
		return "utf-8";


	}

}
