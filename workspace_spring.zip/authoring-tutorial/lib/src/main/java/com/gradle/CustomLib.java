package com.gradle;

public class CustomLib {
    public static String identifier = "I'm a String from a lib.";
}