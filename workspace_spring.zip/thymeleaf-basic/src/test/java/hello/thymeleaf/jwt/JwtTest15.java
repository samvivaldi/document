package hello.thymeleaf.jwt;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.json.JSONException;
import org.json.JSONObject;

public class JwtTest15 {

	private static String SECRET_KEY = "asdfasdfasdfasdfsadfasdf";

	public static void main(String[] args) throws Exception {
		
		
		JwtExample jwtExample = new JwtExample();
		
		String tokenExample = jwtExample.createJwtToken();
		System.out.println("tokenExample: " + tokenExample);
		boolean isValid2 = JwtTest15.parseJwtToken(tokenExample);
		System.out.println("Is Valid2 Token: " + isValid2);		
		
		
		String jwtToken = JwtTest15.createJwtToken15();
		System.out.println("JWT Token: " + jwtToken);

		// Parse and validate JWT token
		boolean isValid = JwtTest15.parseJwtToken(jwtToken);
		System.out.println("Is Valid Token: " + isValid);
		
		
		System.out.println("\n\n\n========개발===================");
		
		String str = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyMDI0MDExOSIsIm5hbWUiOiJORiIsImlhdCI6InNwZGxxanFscnlydXN3anJyb3FrZiIsInN2IjoiZGV2In0.j5X4fus0RtaVmznw3kYFXEoRCOLdt2B4ZecW3xLQh-M";
		JwtTest15.parseJwtToken(str);

		System.out.println("\n\n\n========운영===================");
		
		String str2 = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyMDI0MDExOSIsIm5hbWUiOiJORiIsImlhdCI6InNwZGxxanFscnlydXN3anJkbnNkdWQiLCJzdiI6InJlYWwifQ.TAOwaql8BKIz6EtzjXDJ04_gScZ5GL05v7F8ZejYpsY";
		JwtTest15.parseJwtToken(str2);

	}

	public static String createJwtToken15() throws NoSuchAlgorithmException, InvalidKeyException, IllegalStateException, UnsupportedEncodingException, JSONException {
		String header =  "{\"alg\":\"HS256\",\"typ\":\"JWT\"}";
		String payload = "{\"sub\":\"subject\",\"userId\":\"9000229\",\"userName\":\"sam\"}";
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("sub", "subject");
		jsonObject.put("userId", "9000229");
		jsonObject.put("userName", "sam");

		System.out.println("jsonObject :" + jsonObject);
		
		String headerBase64 = Base64.getEncoder().encodeToString(header.getBytes("UTF-8")).replaceAll("=", "");
		String payloadBase64 = Base64.getEncoder().encodeToString(payload.getBytes("UTF-8")).replaceAll("=", "");
	
		
		System.out.println("headerBase64 :" + headerBase64);
		System.out.println("payloadBase64 :" + payloadBase64);

		String data = headerBase64 + "." + payloadBase64;
//		String data = headerBase64 + "." + payloadBase64.substring(0, payloadBase64.length() -1 );
		String signature = JwtTest15.calculateHMAC(data, SECRET_KEY);

		
		return data + "." + signature;
	}

	public static String calculateHMAC(String data, String key) throws NoSuchAlgorithmException, InvalidKeyException, IllegalStateException, UnsupportedEncodingException {
		String algorithm = "HmacSHA256";
		byte[] keyBytes = key.getBytes("UTF-8");
		SecretKeySpec signingKey = new SecretKeySpec(keyBytes, algorithm);
		Mac mac = Mac.getInstance(algorithm);
		mac.init(signingKey);
		
		return Base64.getEncoder().encodeToString(mac.doFinal(data.getBytes("UTF-8"))).replaceAll("=", "");
	}

	public static boolean parseJwtToken(String token) throws NoSuchAlgorithmException, InvalidKeyException, IllegalStateException, UnsupportedEncodingException {
		String[] parts = token.split("\\.");
		if (parts.length != 3) {
			return false;
		}
		
		System.out.println("token:" + token);
		
		String header = new String(Base64.getDecoder().decode(parts[0]));
		String payload = new String(Base64.getDecoder().decode(parts[1]));
		System.out.println("header:" + header);
		System.out.println("payload:" + payload);
		

		String data = parts[0] + "." + parts[1];
		System.out.println("parts[0]" + parts[0]);
		System.out.println("parts[1]" + parts[1]);
		String signature = JwtTest15.calculateHMAC(data, SECRET_KEY);
		System.out.println("signature:" + signature);
		return signature.equals(parts[2]);
	}
	

}
