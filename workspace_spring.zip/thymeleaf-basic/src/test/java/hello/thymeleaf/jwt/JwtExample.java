package hello.thymeleaf.jwt;

import java.util.Date;

import org.junit.jupiter.api.Test;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Header;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class JwtExample {

	private static final String SECRET_KEY = "asdfasdfasdfasdfsadfasdf";
	                                          
	@Test
	public void testJwt() {

		String jwtToken = createJwtToken();
		System.out.println("JWT Token: " + jwtToken);

		// Parse and validate JWT token
		System.out.println("인증 성공 여부 : " + parseJwtToken(jwtToken));

		System.out.println("인증 성공 여부 : " + parseJwtToken(jwtToken + "aa"));

		// head + payload + sing

	}

	public String createJwtToken() {
		String token = Jwts.builder().setSubject("subject")
				.claim("userId", "9000229") // Payload에 추가할 클레임
				.claim("userName", "sam") // Payload에 추가할 클레임
				//.setIssuedAt(new Date()).setExpiration(new Date(System.currentTimeMillis() + 60 * 60 * 1000)) // 1 hour
				.signWith(SignatureAlgorithm.HS256, SECRET_KEY)
				.setHeaderParam("alg", "HS256")
				.setHeaderParam("typ", "JWT")
				.compact();

		Header header = Jwts.parser().setSigningKey(SECRET_KEY).parse(token).getHeader();
		System.out.println("header:" + header);
		
		Object body = Jwts.parser().setSigningKey(SECRET_KEY).parse(token).getBody();
		
		System.out.println("body:" + body);
		
		return token;
	}

	public boolean parseJwtToken(String token) {
		try {
			Claims claims = Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();

			System.out.println("Subject: " + claims.getSubject());
			System.out.println("Expiration: " + claims.getExpiration());
			
			System.out.println(claims.get("userId"));
			System.out.println(claims.get("userName"));
			
			
		} catch (Exception e) {
			/* io.jsonwebtoken.SignatureException */
			System.out.println(e.getMessage());
			return false;
		}
		return true;
	}
	 
	
}
