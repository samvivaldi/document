package hello.login.web.interceptor;

import org.springframework.boot.web.server.ConfigurableWebServerFactory;
import org.springframework.boot.web.server.ErrorPage;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class WebServerConfig implements WebServerFactoryCustomizer<ConfigurableWebServerFactory>{

	@Override
	public void customize(ConfigurableWebServerFactory factory) {
		
		ErrorPage errorPage = new ErrorPage(HttpStatus.NOT_FOUND, "aa");
		factory.addErrorPages(errorPage);
		
	}
	
	

}
