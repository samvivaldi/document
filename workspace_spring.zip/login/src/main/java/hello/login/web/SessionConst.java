package hello.login.web;

public class SessionConst {
    public static final String LOGIN_MEMBER = "loginMember";
}
