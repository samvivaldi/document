package hello.login.domain.item;

public interface UpdateCheck {
}