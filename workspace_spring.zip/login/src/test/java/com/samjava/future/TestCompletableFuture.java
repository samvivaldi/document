package com.samjava.future;

import static org.junit.jupiter.api.Assertions.*;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class TestCompletableFuture {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	void test() throws InterruptedException, ExecutionException {
		
		@SuppressWarnings("unused")
		CompletableFuture<Void> runAsync = CompletableFuture.runAsync(() -> System.out.println("CompletableFuture"));
		
		CompletableFuture<String> supplyAsync = CompletableFuture.supplyAsync(() -> {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			return "결과반환";
		});
		
//		thenApply: 작업 결과를 처리하고 반환합니다.
//		thenAccept: 결과를 소비만 합니다(반환값 없음).
//		thenRun: 작업 후 특정 동작을 실행합니다(결과를 사용하지 않음).
		
		supplyAsync
		.thenApply(result -> "처리된 결과: " + result)	/* 작업 결과를 처리하고 반환합니다. */
//		.thenAccept(result -> System.out.println(result));
		.thenAccept(System.out::println)
//		.get();
		.join();
		
	}
	
	@Test
	void Test2() throws InterruptedException, ExecutionException {
		
		CompletableFuture<String> future1 = CompletableFuture.supplyAsync(() -> "작업 1");
		CompletableFuture<String> future2 = CompletableFuture.supplyAsync(() -> "작업 2");

		future1.thenCombine(future2, (result1, result2) -> result1 + " + " + result2)
		       .thenAccept(System.out::println)
		       .get();
		
		
		
	}

	
	@Test
	void Test3() throws InterruptedException, ExecutionException {
		
		CompletableFuture<String> future1 = CompletableFuture.supplyAsync(() -> {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			return "작업 1";
		});
		CompletableFuture<String> future2 = CompletableFuture.supplyAsync(() -> "작업 2");
		CompletableFuture<String> future3 = CompletableFuture.supplyAsync(() -> "작업 3");

		CompletableFuture<String> finalCombinedFuture = 
			    future1.thenCombine(future2, (result1, result2) -> result1 + ", " + result2)
			           .thenCombine(future3, (partialResult, result3) -> partialResult + ", " + result3);

		finalCombinedFuture.thenAccept(System.out::println).join();
		
		
	}	
	
	@Test
	void test1_1() {
		
		CompletableFuture<String> supplyAsync = CompletableFuture.supplyAsync(() -> {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			return "결과반환";
		});
		
		
		
		
		try {
			supplyAsync
			.thenApply(result -> "처리된 결과: " + result)	
			.thenAccept(System.out::println)
			.get();
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	

}
