package com.samjava.future;

import java.util.concurrent.CompletableFuture;

public class MainTest {

	public static void main(String[] args) {
		
        CompletableFuture<String> future1 = CompletableFuture.supplyAsync(() -> {
        
        	try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        	return "작업 1";
        });
        CompletableFuture<String> future2 = CompletableFuture.supplyAsync(() -> "작업 2");
        CompletableFuture<String> future3 = CompletableFuture.supplyAsync(() -> "작업 3");

        // future1과 future2 결합
        CompletableFuture<String> combinedFuture1 = future1.thenCombine(future2, (result1, result2) -> result1 + ", " + result2);

        // combinedFuture1과 future3 결합
        CompletableFuture<String> finalCombinedFuture = combinedFuture1.thenCombine(future3, (partialResult, result3) -> partialResult + ", " + result3);

        // 최종 결과 출력
        finalCombinedFuture.thenAccept(System.out::println);

        // 대기 (main 종료 방지)
        finalCombinedFuture.join();
		

	}

}
