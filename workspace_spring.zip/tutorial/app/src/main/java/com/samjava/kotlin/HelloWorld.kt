package com.samjava.kotlin


fun main(args: Array<String>) {
    //println("program arguments: ${args[0]}");
    println("Program arguments: ${args.contentToString()}")
}
