package com.samjava.kotlin

class Test {
    fun printStr():String{
        return "test"
    }
}

fun main(args:Array<String>) {
    for (i in 10 downTo 1 step 2) println(i)
}