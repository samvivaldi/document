package hello.core.scan;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import hello.core.AutoAppConfig;
import hello.core.member.Member;
import hello.core.member.MemberService;

public class AutoAppConfigTest {
	
	@Test
	void basicScan() {
		
		@SuppressWarnings("resource")
		ApplicationContext ac = new AnnotationConfigApplicationContext(AutoAppConfig.class);
		MemberService memberService = ac.getBean(MemberService.class);
		
		AutoAppConfig bean = ac.getBean(AutoAppConfig.class);
		
		System.out.println(bean.getClass());
		System.out.println(memberService.getClass());
		System.out.println(memberService);
		
//		Member member = ac.getBean(Member.class);
//		System.out.println("member :" + member);
		
		assertThat(memberService).isInstanceOf(MemberService.class);
		
		
	}
}