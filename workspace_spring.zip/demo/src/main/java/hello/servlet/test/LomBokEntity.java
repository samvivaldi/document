package hello.servlet.test;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString

public class LomBokEntity {
	private String name;
	private int age;
	private String adress;
	
	
	private void test() {
		LomBokEntity lomBokEntity = new LomBokEntity();
		lomBokEntity.setAdress("seoul");
		
	}
}



