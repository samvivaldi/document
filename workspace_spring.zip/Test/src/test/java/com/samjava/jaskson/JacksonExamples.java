package com.samjava.jaskson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class JacksonExamples {
    public static void main(String[] args) throws IOException {
        objectToJsonExample();
        jsonToObjectExample();
//        jsonNodeExample();
//        customAnnotationsExample();
    }

    // Example 1: Object to JSON Serialization
    private static void objectToJsonExample() throws JsonProcessingException {
        Person person = new Person("Alice", 30);
        
        person.setPhone(Arrays.asList("01022223333", "01011115555"));
        
        
        
        ObjectMapper mapper = new ObjectMapper();
        String jsonString = mapper.writeValueAsString(person);
        System.out.println("Serialized JSON: " + jsonString);
    }

    // Example 2: JSON to Object Deserialization
    private static void jsonToObjectExample() throws JsonProcessingException {
        String jsonString = "{\"name\":\"Alice\",\"age\":30,\"phone\":[\"01022223333\",\"01011115555\"]}";
        ObjectMapper mapper = new ObjectMapper();
        Person person = mapper.readValue(jsonString, Person.class);
        System.out.println("Deserialized Object: " + person);
        
        
        HashMap map = mapper.readValue(jsonString, HashMap.class);
        System.out.println("map :" + map);
        
    }

    // Example 3: Working with JsonNode
    private static void jsonNodeExample() throws JsonProcessingException {
        String jsonString = "{\"name\":\"Charlie\",\"details\":{\"age\": 40,\"city\":\"Seoul\"}}";
        ObjectMapper mapper = new ObjectMapper();
        JsonNode rootNode = mapper.readTree(jsonString);

        // Access nested fields
        String name = rootNode.get("name").asText();
        int age = rootNode.get("details").get("age").asInt();
        String city = rootNode.get("details").get("city").asText();

        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("City: " + city);

        // Modify JSON dynamically
        ((ObjectNode) rootNode).put("country", "South Korea");
        String modifiedJson = mapper.writeValueAsString(rootNode);
        System.out.println("Modified JSON: " + modifiedJson);
    }

    // Example 4: Custom Annotations
    private static void customAnnotationsExample() throws JsonProcessingException {
        Product product = new Product("Laptop", 1200.99, "This is a high-end laptop");
        ObjectMapper mapper = new ObjectMapper();

        String jsonString = mapper.writeValueAsString(product);
        System.out.println("Product JSON with Annotations: " + jsonString);
    }

    // Person Class for Examples
    static class Person {
        private String name;
        private int age;
        private List<String> phone;

        public List<String> getPhone() {
			return phone;
		}

		public void setPhone(List<String> phone) {
			this.phone = phone;
		}

		public Person() {
        }

        public Person(String name, int age) {
            this.name = name;
            this.age = age;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }

        @Override
        public String toString() {
            return "Person{name='" + name + "', age=" + age + "}";
        }
    }

    // Product Class with Custom Annotations
    static class Product {
        @JsonProperty("product_name")
        private String name;

        private double price;

        @JsonIgnore
        private String description;

        public Product() {
        }

        public Product(String name, double price, String description) {
            this.name = name;
            this.price = price;
            this.description = description;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public double getPrice() {
            return price;
        }

        public void setPrice(double price) {
            this.price = price;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        @Override
        public String toString() {
            return "Product{name='" + name + "', price=" + price + "}";
        }
    }
}
