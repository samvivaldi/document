package com.samjava.jaskson;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

class JasksonTest2 {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void test() {
		System.out.println("call JasksonTest.jsonTest()");

		String json = "{ \"name\": \"Alice\", \"age\": 30, \"address\": { \"city\": \"Seoul\", \"zip\": \"12345\" } }";

		ObjectMapper mapper = new ObjectMapper();

		// JSON 문자열을 JsonNode로 읽기
		JsonNode rootNode = null;
		try {
			rootNode = mapper.readTree(json);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// 특정 필드 값 추출
		String name = rootNode.get("name").asText();
		int age = rootNode.get("age").asInt();
		String city = rootNode.get("address").get("city").asText();

		System.out.println("Name: " + name);
		System.out.println("Age: " + age);
		System.out.println("City: " + city);

		JsonNode jsonNode = rootNode.get("name");

	}

	@Test
	void test2() throws JsonProcessingException {
		System.out.println("call JasksonTest2.test2()");

		List<String> list = Arrays.asList("a", "b", "c");
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put("1", "3333");
		data.put("2", "BB");
		data.put("3", "CC");
		data.put("4", list);

		data.put("address", Map.of("city", "Seoul", "zip", "12345"));

		ObjectMapper mapper = new ObjectMapper();
		String jsonString = mapper.writeValueAsString(data);
		
		System.out.println("jsonString :" + jsonString);

		JsonNode rootNode = mapper.readTree(jsonString);
		
		
		JsonNode node1 = rootNode.get("4");
		JsonNode node2 = rootNode.get("1");
		

		System.out.println("isArray:" + rootNode.get("4").isArray());
		System.out.println("isArray:" + rootNode.get("1").isArray());

		System.out.println("1 :" + rootNode.get("1").asText());
		System.out.println("1 :" + rootNode.get("1").asInt());

		System.out.println("4 :" + rootNode.get("4"));

		JsonNode jsonNode2 = rootNode.get("4");

		for (JsonNode node : jsonNode2) {
			System.out.println("aaaa :" + node.asText());
		}
//        
//        for (JsonNode node : jsonNode) {
//        	System.out.println("bbb :" +  node.);	
//		}
		System.out.println("==================================================");
		printJsonNode(rootNode);
	}

	
	private void printJsonNode(JsonNode node) {
		if (node.isObject()) { // JSON 객체인 경우
			Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
			while (fields.hasNext()) {
				Map.Entry<String, JsonNode> entry = fields.next();
				System.out.println("Key: " + entry.getKey() + ", value:" + entry.getValue());
			}
		} else if (node.isArray()) { // JSON 배열인 경우
			
//			for (JsonNode arrayElement : node) {
//				printJsonNode(arrayElement);
//			}

			System.out.print("array :");
			for (JsonNode arrayElement : node) {
				System.out.print(", " + arrayElement.asText());
			}

			System.out.println();
		} else { // 일반 값인 경우
			System.out.println("Value: " + node.asText());
		}
	}

}
