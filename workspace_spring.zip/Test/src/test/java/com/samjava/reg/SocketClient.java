package com.samjava.reg;

import java.io.*;
import java.net.*;

public class SocketClient {

    public static void main(String[] args) {
        String serverAddress = "127.0.0.1"; // 서버 IP (로컬 테스트용)
        int serverPort = 5000; // 서버 포트

        try {
        	Socket socket = new Socket(serverAddress, serverPort);
        
             OutputStream outputStream = socket.getOutputStream();
             InputStream inputStream = socket.getInputStream();
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream));
             BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream)) ;
            
            // 서버로 데이터 전송
            String messageToSend = "333333333443555555555555555555555555";
            writer.write(messageToSend);
            writer.newLine(); // 개행 추가 (서버에서 읽기 용이하도록)
            writer.flush();

            // 서버로부터 응답 수신
            String response = reader.readLine();
            System.out.println("서버 응답: " + response);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
