package com.samjava.reg;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RegTest {

	ArrayList<String> phonNumList = new ArrayList<String>();
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		
	}

	@BeforeEach
	void setUp() throws Exception {
		
		phonNumList = new ArrayList<String>();
		phonNumList.add("010290632333");
		phonNumList.add("01029063233");
		phonNumList.add("0102903233");		
		phonNumList.add("010203233");		
	}

	@AfterEach
	void tearDown() throws Exception {
		
	}

	@Test
	void test() {
		
		Pattern p = Pattern.compile("(\\d{3})(\\d{3,4})(\\d{4})");
		
		for (String pNum : phonNumList) {
			
			Matcher matcher = p.matcher(pNum);
			
			if (matcher.matches()) {
				
				String output = "";
//				System.out.println("matcher :" + matcher);
//				System.out.println("matcher.groupCount() :" + matcher.groupCount());
				
				for (int i = 1; i < matcher.groupCount() ; i++) {
					output += matcher.group(i) + "-";
					
				}
				
				output += matcher.group(matcher.groupCount());
				System.out.printf("phone number %s : %s\n", pNum, output);
			}
			
		}
	}
	
	@Test
	void test2() {
		
		for (String pNum : phonNumList) {
			System.out.printf("phone number %s : %s\n", pNum, Pattern.matches("\\d{3}\\d{3,4}\\d[4]", pNum));
		}
		
	}	
	
	@Test
	void test3() {
		
		System.out.println(Pattern.matches("[가-힝]+", "ㄱㄹ김김김삼ㅇ"));
		System.out.println(Pattern.matches("[가-힝]+", "김김김삼"));
		System.out.println(Pattern.matches("[가-힝]+", "가고항김김김삼"));
		
	}		

}
