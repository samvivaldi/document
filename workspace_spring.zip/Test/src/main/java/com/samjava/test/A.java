package com.samjava.test;

public class A {
    public synchronized void methodA() {
        System.out.println(Thread.currentThread().getName() + " is in methodA");
        try {
            Thread.sleep(2000); // 2초 동안 대기
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(Thread.currentThread().getName() + " is leaving methodA");
    }
}