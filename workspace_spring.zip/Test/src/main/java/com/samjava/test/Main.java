package com.samjava.test;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Main {

	public static void main(String[] args) {
		
		A a1 = new A();
		A a2 = new A();
		
		Thread t1 = new Thread(() -> a1.methodA(), "Thread-1");
		Thread t2 = new Thread(() -> a2.methodA(), "Thread-2");
		
		log.info("{} : {}" + Main.class.getName(), Thread.currentThread().getName());
		
		t1.start();
		t2.start();
		
	}
}
