package com.samjava.jaskson;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Jaskson {

	public static void main(String[] args) throws Exception {
		System.out.println("call JasksonTest.jsonTest()");
		
		String json = "{ \"name\": \"Alice\", \"age\": 30, \"address\": { \"city\": \"Seoul\", \"zip\": \"12345\" } }";

        ObjectMapper mapper = new ObjectMapper();

        // JSON 문자열을 JsonNode로 읽기
        JsonNode rootNode = mapper.readTree(json);

        // 특정 필드 값 추출
        String name = rootNode.get("name").asText();
        int age = rootNode.get("age").asInt();
        String city = rootNode.get("address").get("city").asText();

        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("City: " + city);	

	}

}
