package hello.coupang;

import java.io.File;
import java.io.FileOutputStream;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class RestApiClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		System.out.println(args.length);
		
		RestApiClient restApiClient = new RestApiClient();

//		restApiClient.reqestGet();
		
		
		if (args.length == 0) {
			restApiClient.reqestPost("91주9470");
		} else {
			restApiClient.reqestPost(args[0]);	
		}
	}

	public void reqestJson() {

	}

	public void reqestPost(String carNo) {

		String apiUrl = "http://devlap.axa.co.kr/AsianPlatformWAS/jsp/ap/auto/cone/test/CopangTest.jsp";

		// 아파치 HTTP 클라이언트 생성
		HttpClient client = new HttpClient();

		PostMethod postMethod = new PostMethod(apiUrl);
//		postMethod.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		postMethod.setRequestHeader("Content-Type", "application/json;charset=euc-kr");
		
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("CAR_NO", carNo);
//		jsonObj.put("CAR_NO", "aa");
//		jsonObj.put("CHASI_NO", "KNFSTZ76AGK021868");
		
		postMethod.setRequestBody(jsonObj.toString());
		
		try {
			// HTTP 요청 실행
			int statusCode = client.executeMethod(postMethod);

			// 응답 코드 확인
			if (statusCode == 200) {
				// 응답 내용 출력
				System.out.println("Response Body|" + postMethod.getResponseBodyAsString() + "|");
				
				String responseBody = postMethod.getResponseBodyAsString();
				
				JSONParser parser = new JSONParser();
				JSONObject resopnseJson = (JSONObject)parser.parse(responseBody);				
				
				System.out.println("resultData |" + resopnseJson + "|");
				
				if (resopnseJson.get("fileByte") == null) {
					System.out.println("조회된 데이타가 존재하지 않습니다");
					return;
				}
				
				byte[] fileByte = Base64.decodeBase64((String)resopnseJson.get("fileByte"));
				
		        // 파일에 내용 쓰기
		        FileOutputStream out = new FileOutputStream(new File((String)jsonObj.get("CAR_NO") + ".pdf"));
		        out.write(fileByte);
		        out.close();				
				
				
			} else {
				System.err.println("HTTP Request Failed - Status Code: " + statusCode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 반드시 메서드를 release하여 리소스를 해제해야 합니다.
			postMethod.releaseConnection();
		}

	}

	public void reqestGet() {
		String apiUrl = "http://devlap.axa.co.kr/AsianPlatformWAS/jsp/ap/auto/cone/test/CopangTest.jsp";

		// 아파치 HTTP 클라이언트 생성
		HttpClient client = new HttpClient();

		// GET 메서드 생성
		GetMethod getMethod = new GetMethod(apiUrl);

		try {
			// HTTP 요청 실행
			int statusCode = client.executeMethod(getMethod);

			// 응답 코드 확인
			if (statusCode == 200) {
				// 응답 내용 출력
				System.out.println("Response Body: " + getMethod.getResponseBodyAsString());
			} else {
				System.err.println("HTTP Request Failed - Status Code: " + statusCode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 반드시 메서드를 release하여 리소스를 해제해야 합니다.
			getMethod.releaseConnection();
		}

	}

}
