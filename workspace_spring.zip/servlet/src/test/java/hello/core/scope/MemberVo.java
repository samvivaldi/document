package hello.core.scope;

import lombok.Data;

//@RequiredArgsConstructor
@Data
public class MemberVo {
	
	private final String name;
	private final String age;

}
