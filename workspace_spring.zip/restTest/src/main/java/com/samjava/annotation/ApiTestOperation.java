package com.samjava.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;


@Target(ElementType.METHOD) 
@Retention(RetentionPolicy.RUNTIME) 
@Inherited 
@ApiResponses(value = 
{
@ApiResponse(responseCode = "200", description = "사용자 목록 조회 성공"
			, content = 
			{
					@Content(mediaType = "application/json"
					, examples = @ExampleObject(value = "{\"get\":\"get\",\"name\":\"sam\",\"id\":\"900229\"}"))
	        }),
@ApiResponse(responseCode = "404", description = "User not found"
, content = 
{
		@Content(mediaType = "application/json"
		, examples = @ExampleObject(value = "{\"err_cd\":\"abcdef\",\"err_desc\":\"sam에게 문의하세요\"}"))
}),		
}
)
public @interface ApiTestOperation {

}
