package com.samjava.rest;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.samjava.annotation.ApiTestOperation;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class ApiTestController {
	

//	@Autowired
//	ObjectMapper objectMapper;
	
	private ObjectMapper objectMapper;
	public ApiTestController(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}
	
    /**
     * @param id javadoc은 어떻게 만들어지지?
     * @param name 여기는 javadoc수석의 이름부분
     * @return
     * @throws JsonProcessingException
     */
	@GetMapping("/api/members/{id}/{name}")
	@Operation(summary = "call getMember", description = "sam님이 swagger 테스트 해볼려고 만든 API.")
	@ApiTestOperation
	public String getMember(
			@Parameter(description = "id를 필수값입니다.", required = true, example = "900229")
			@PathVariable("id") String id
			, 
    		@Parameter(example = "sam") 
    		@PathVariable("name") String name) throws JsonProcessingException {
        System.out.println("getMember ID: " + id);
        System.out.println("name: " + name);

		Map<String, Object> hm = new HashMap<String, Object>();
		hm.put("id", id);
		hm.put("name", name);
		hm.put("get", "get");
		
		
        return objectMapper.writeValueAsString(hm);   
    }
    
    @PostMapping("/api/members/{id}/{name}")
    @Operation(summary = "postMember", description = "json 데이타를 돌려준다.")
    public String postMember(
    		@PathVariable("id") String id, @PathVariable("name") String name, @RequestBody(required = false) String requestBody) throws JsonProcessingException {

        System.out.println("insertMember ID:" + id);
        System.out.println("Request Body: " + requestBody);

        Map<String, Object> hm = new HashMap<String, Object>();
		hm.put("id", id);
		hm.put("name", name);
		hm.put("put", "put");
		
		String valueAsString = objectMapper.writeValueAsString(hm);
		
        return valueAsString;
    }	    
    
}
