package com.samjava.rest;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

class ApiTestControllerTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	void test() throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		
		Map<String, Object> hm = new HashMap();
		hm.put("aaa", "222");
		hm.put("bbb", "222");
		
		String valueAsString = objectMapper.writeValueAsString(hm);
		System.out.println("valueAsString :" + valueAsString);
		
	}

}
