import os
import zipfile

def zip_class_files(start_dir, zip_filename):
    """
    start_dir: 특정 디렉토리 경로 (str)
    zip_filename: 생성할 zip 파일 이름 (str)
    """
    # 하위 디렉토리에서 클래스 파일 경로 추출
    class_files = []
    for dirpath, dirnames, filenames in os.walk(start_dir):
        if 'model' in dirnames:
            model_dir = os.path.join(dirpath, 'model')
            for filename in os.listdir(model_dir):
                if filename.endswith('.class'):
                    class_files.append(os.path.join(model_dir, filename))
                    print(os.path.join(model_dir, filename))

    # zip 파일 생성
    with zipfile.ZipFile(zip_filename, 'w') as zip:
        for file in class_files:
            zip.write(file)

    print(f'Successfully created {zip_filename}')
