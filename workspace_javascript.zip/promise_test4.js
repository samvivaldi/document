Promise.all([
  new Promise(resolve => setTimeout(() => resolve(1), 3000)), // 1
  new Promise(resolve => setTimeout(() => resolve(2), 2000)), // 2
  new Promise(resolve => setTimeout(() => resolve(3), 1000))  // 3
]).then(
  result => {
    console.log(result);
    console.log("typeof", typeof(reslut));
    result.forEach(element => {
        console.log(`element ${element}`);
    });

  }
); 




async function fn1()  {
    let url = 'https://www.naver.com';
    let response = await fetch(url);

    let commits = await response.json(); // 응답 본문을 읽고 JSON 형태로 파싱함

    console.log(commits[0].author.login);
}

fn1();



var reg = /\B(?=(\d{3})+(?!\d))/;



var reg2 = /<br>.*?<\/br>/;

var reg3 = /\d+/g;