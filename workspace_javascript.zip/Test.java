import java.text.ParseException;
import java.time.LocalDate;

public class Test {

    public static void main(String[] args) throws ParseException {
        System.out.println("aaa");

        Test test = new Test();
        test.testA();
    }

    /**
     * @throws ParseException
     * 
     */
    public void testA() throws ParseException {

        LocalDate today = LocalDate.now();
        System.out.println("오늘 날짜: " + today);

        String str = "";
        

    }

}
