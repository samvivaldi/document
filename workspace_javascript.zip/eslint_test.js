let arr = [1,2,3,4];

ar.a ;


arr.mAp(() => '');
