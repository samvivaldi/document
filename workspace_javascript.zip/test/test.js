arr = [1, 2, 3, 4, 5];

let arr2 = arr.map(val=>(val*val))

console.log(arr2);

let arr3 = arr.reduce((p,n)=>p+n, 10);

console.log(arr3);