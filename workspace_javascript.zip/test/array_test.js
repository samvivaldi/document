/*
   forEach
*/

debugger;
console.log("====================  forEach =====================");
let arr = ["aaa", "bbb", "ccc"];
arr.forEach((item) => {
  console.log(item);
});

arr.forEach((item, index, array) => {
  console.log(`${item} "is" at '' index ${index} in ${array}`);
});




/*
기본 정렬 순서는 문자열 Unicode 코드 포인트 순서에 따른다. 배열의 요소가 숫자 타입이라 할지라도 배열의 요소를 일시적으로 문자열로 변환한 후, 정렬한다.
*/
console.log("==================== sort =====================");
let points = [40, 100, 1, 5, 3, 25, 10];
let chgPoints = points.sort();
console.log("chgPoints:", chgPoints); // [ 1, 10, 100, 2, 25, 40, 5 ]
console.log("points:", points); // [ 1, 10, 100, 2, 25, 40, 5 ]
points.sort((a,b) => a-b);


console.log(points);

let todos = [
    { id: 4, content: 'JavaScript' },
    { id: 1, content: 'HTML' },
    { id: 2, content: 'CSS' }
  ];
//let compare = key => (a,b) => a[key] < b[key] ? -1 : (a[key] > b[key] ? 1 : 0);


let compare = function(key) {
  return function(a, b) {
    return  a[key] < b[key] ? -1 : (a[key] > b[key] ? 1 : 0);
  }
}


todos.sort(compare('id'));
console.log("todos.sort(compare('id')) :" , todos);



console.log("====================  find / findIndex / filter =====================");
let users = [
  { id: 1, name: "Lee" },
  { id: 2, name: "Kim" },
  { id: 2, name: "Choi" },
  { id: 3, name: "Park" },
];

let result = users.find((item) => item.id === 2);
console.log("users.find((item) => item.id === 2) : ", result);

const array1 = [5, 30, 8, 130, 44];

const isLargeNumber = (element) => element > 13;

console.log("array1.findIndex(isLargeNumber):", array1.findIndex(isLargeNumber));

let isLargeNumber2 = (inputIdx) => (element, index) => index > inputIdx && element > 13;

console.log("array1.findIndex(isLargeNumber2(1)) : ", array1.findIndex(isLargeNumber2(1)));

result = users.filter((item) => item.id === 2);
console.log("filetr : ", result);


console.log("====================  map =====================");
let numbers = [1, 4, 9];

// 배열을 순회하며 각 요소에 대하여 인자로 주어진 콜백함수를 실행
let roots = numbers.map(Math.sqrt);

console.log("roots:", roots);   
console.log("numbers:", numbers);  /* 원본에 대한 변경이 없음 */

let lengths = ["Bilbo", "Gandalf", "Nazgul"].map(item => item.length);
console.log("lengths:", lengths); // 5,7,6


let ex1 = function(user) {
  user.id = 'UID_' + user.id;
  user.name = 'UID_' + user.name;
  user.grade = 'A+';
  return user;
}

let changeUsers = users.map(user => {
  user.id = 'UID_' + user.id;
  user.name = 'UID_' + user.name;
  user.grade = 'A+';
  return user;
});
console.log("changeUsers:", changeUsers);   

console.log("====================  reduce =====================");

arr = [1, 2, 3, 4, 5];

/*
previousValue: 이전 콜백의 반환값
currentValue : 배열 요소의 값
currentIndex : 인덱스
array        : 메소드를 호출한 배열, 즉 this
*/
const sum = arr.reduce(function (previousValue, currentValue, currentIndex, self) {
  console.log(previousValue + '+' + currentValue + '=' + (previousValue + currentValue));
  return previousValue + currentValue; // 결과는 다음 콜백의 첫번째 인자로 전달된다
});

console.log("sum:" , sum); // 15: 1~5까지의 합

let max = arr.reduce(function (pre, cur) {
  return pre > cur ? pre : cur;
});
console.log("max:" , max); 

let products = [
  { id: 1, price: 100 },
  { id: 2, price: 200 },
  { id: 3, price: 300 }
];


let priceSum = products.reduce(function (pre, cur) {
  console.log(pre, cur.price);
  return pre + cur.price;
}, 0);

console.log("priceSum:", priceSum); 

let priceSum2 = products.reduce((pre, cur) => pre + cur.price, 0);
console.log("priceSum2:", priceSum2); 


console.log("====================  some / every =====================");
let res = [2, 5, 8, 1, 4].some(function (item) {
  return item > 10;
});
console.log(res); // false

res = [12, 5, 8, 1, 4].some(function (item) {
  return item > 10;
});
console.log(res); // true

// 배열 내 모든 요소가 10보다 큰 값인지 확인
 res = [21, 15, 89, 1, 44].every(function (item) {
  return item > 10;
});
console.log(res); // false

res = [21, 15, 89, 100, 44].every(function (item) {
  return item > 10;
});
console.log(res); // true

console.log("==================== callback function의 this =====================");

var Person = (function() {
  function Person(name) {
    this.name = name;
  }

  Person.prototype.sayHi = function() {
    console.log("persion ojb sayHi : " + this.name);
  }

  Person.prototype.addSample = function (arr) {
    return arr.map(function (val) {
      return this.name + " "+ val;
    }.bind(this));
  }

  Person.prototype.addSample2 = function (arr) {
    return arr.map((val) => this.name + " "+ val)
  }

  return Person;

})();

let p1 = new Person('sam');
p1.sayHi();
console.log(p1.addSample(['kim', 'lee', 'jung']));
console.log(p1.addSample2(['kim', 'lee', 'jung']));



