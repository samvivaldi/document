
console.log('====================  splice =====================') 
/* pop / push ,  shift/ unshift */
let fruits = ["사과", "오렌지", "배"];
console.log(`fruits  ${fruits}`)
console.log(`1. fruits.pop()  ${fruits.pop()}`);
console.log(`2. fruits  ${fruits}`)



console.log(`3. fruits.push("배")  ${fruits.push("배")}`);
console.log(`4. fruits  ${fruits}`)

console.log(`5. fruits.shift  ${fruits.shift()}`);
console.log(`6. fruits  ${fruits}`)

console.log(`7. fruits.unshift('사과')  ${fruits.unshift('사과')}`);
console.log(`8. fruits  ${fruits}`)


/*
arr.splice(index[, deleteCount, elem1, ..., elemN])
첫 번째 매개변수는 조작을 가할 첫 번째 요소를 가리키는 인덱스(index)입니다. 
두 번째 매개변수는 deleteCount로, 제거하고자 하는 요소의 개수를 나타냅니다. 
elem1, ..., elemN은 배열에 추가할 요소
*/
console.log('====================  splice =====================') 
let arr = ["I", "study", "JavaScript", "right", "now"];
console.log( arr ) 
arr.splice(0, 3, "Let's", "dance");
console.log( arr ) 

/*
slice(start, end) – start부터 end 바로 앞까지의 요소를 복사해 새로운 배열을 만듦
*/
console.log('====================  slice =====================') 
arr = ["t", "e", "s", "t"];
console.log( arr.slice(1, 3) );


/*
concat
*/
console.log('====================  concat =====================') 
arr = [1, 2];

console.log( arr.concat([3, 4]) ); // 1,2,3,4
console.log( arr.concat([3, 4], [5, 6]) ); // 1,2,3,4,5,6
console.log( arr.concat([3, 4], 5, 6) ); // 1,2,3,4,5,6
console.log(arr ); // 1,2

/*
indexOf, lastIndexOf와 includes
*/
console.log('====================  concat =====================') 
arr = [1, 0, false];


console.log( arr.indexOf(0) ); // 1
console.log( arr.indexOf(false) ); // 2
console.log( arr.indexOf(null) ); // -1
console.log( arr.includes(1) ); // true

/*
arr.fill() - 메서드는 배열의 시작 인덱스부터 끝 인덱스의 이전까지 정적인 값 하나로 채웁니다.
*/
console.log('====================  arr.fill() =====================') 
let arrFill = [1, 2, 3, 4];
// fill with 0 from position 2 until position 4
// console.log(arrFill.fill(0, 2, 4));
console.log(arrFill.fill('a', 2, 10));
arrFill.fill(9);
console.log(` arrFill : ${arrFill}`);
console.log(arrFill.fill(5, 2, arrFill.length));


console.log('====================  Array.isArray =====================') 
console.log(typeof {}); // object
console.log(typeof []); // object
console.log(Array.isArray({})); // false
console.log(Array.isArray([])); // true

