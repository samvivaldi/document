var state = {
  information: [
    {
      id: 0,
      name: "김민준",
      phone: "010-0000-0000",
    },
    {
      id: 1,
      name: "홍길동",
      phone: "010-0000-0001",
    },
  ],
  keyword: "",
};

state.keyword = "김";

var filterTest = function () {
  const { information, keyword } = state;
  const filteredList = information.filter((info) => info.name.indexOf(keyword) !== -1);
  //const filteredList = information.filter((info) => info.name.includes(keyword) !== -1);

  console.log("filteredList :", filteredList);

  console.log("=>" + information[0].name.indexOf(keyword));
  console.log("=>" + information[1].name.indexOf(keyword));
};

filterTest();

const numbers = [1, 2, 3, 4];
const evens = numbers.filter((item) => item % 2 === 0);
console.log(evens); // [2, 4]

const double = numbers.map((p) => p * p);
console.log(double);

const test = numbers.reduce((result, p) => p + result, 10);
console.log("reduce:" + test);

var pets = ["dog", "chicken", "cat", "dog", "chicken", "chicken", "rabbit"];
var petCount = pets.reduce(function (obj, p) {
  if (obj[p]) {
    obj[p]++;
  } else {
    obj[p] = 1;
  }
  return obj;
}, {});

console.log("petCount:", petCount);

var petCount2 = pets.reduce((obj, p) => ({ ...obj, [p]: (obj[p] || 0) + 1 }), {});
console.log("petCount2:", petCount2);

////////////////////////////////////////////////

let values = [3, 1, 3, 5, 2, 4, 4, 4];

let uniqueValues = [...new Set(values)];
console.log("uniqueValues : " + uniqueValues);

let params = { lat: 45, lng: 6, alt: 1000 };
var r1 = Object.entries(params).map((p) => p[0] + ";;;" + p[1]);
console.log(r1);
