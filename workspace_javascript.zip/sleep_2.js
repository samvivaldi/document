function sleep(time) {
    return new Promise(resolve => setTimeout(() => resolve(time), time));
}


async function  test() {

    console.time('sleep');
    console.log('start')
    await sleep(3000);
    console.log('end')
    console.timeEnd('sleep');

    Promise.all(sleep(1000), sleep(2000), sleep(3000)).then(resolve => {
        console.log("Promise.all :" + resolve);
    });

}

test();