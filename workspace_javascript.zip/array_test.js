let users = [
  {id: 1, name: "John"},
  {id: 2, name: "Pete"},
  {id: 3, name: "Mary"},
  {id: 1, name: "Sam"}
];

for(let k in users) {
  console.log(`${k} : ${users[k].name}`);
}

for(let k of users) {
  console.log(`${k.id} : ${k.name}`);
}

users[1] = "999"
users['1'] = "99999999"
console.log(users[1]);

console.log(users);

let userFind = users.find(item => item.id == 1);
console.dir(userFind);


let userFilter = users.filter(item => item.id == 1);
console.log(userFilter);


let lengths = ["Bilbo", "Gandalf", "Nazgul"].map(item => item.length);
console.log(lengths);

let arr = [ 1, 2, 19, 15 ];
//let arr = [ 'c', 'z', 'az', 'b' ];
//arr.sort();
console.log(`arr : ${arr}`);  /* 요소는 문자열로 취급되어 재 정렬 */ 

arr.sort((a,b) => a > b?1:a<b?-1:0);
//arr.sort((a,b) => a - b);
console.log(`arr sort: ${arr}`); 


let fnUsersSort = key => {
  let t1 = key;
  return (a, b) => {
    console.log("scope:" + t1);
    return a[key] > b[key] ?1: a[key] < b[key] ? -1 : 0;
  }
};



users.sort(fnUsersSort('id'));

console.log(`users sort result ${JSON.stringify(users)}`);


users.sort(fnUsersSort('name'));

console.log(`users sort result ${JSON.stringify(users)}`);


let result = arr.reduce((sum, current) => sum + current);
console.log(`result ${result}`);

let clTest = () => {
  let i = 0;
  return function()  {
    console.log("i:" + i++);
  }

}

let clFn  = clTest();



clFn();
clFn();
clFn();
clFn();

clFn.a = 'aa';
console.log("===============:" + clFn['a']);

clFn.prototype = {
  fn1 : function() {
    console.log("call fn1");
  }
}

clFn.prototype.fn2 = () => {
  console.log("call fn2");
};

clFn.prototype.constructor = "clFn";

clFn.__proto__.fn3 = () => {
  console.log("call fn3");
};


clFn.fn4 = () => {
  console.log("call fn4");
};

let oclFn = new clFn();
oclFn.fn2();


console.log('======================================');
for(let k in oclFn) {
  console.log(`${k} : ${oclFn[k]}`);
}
console.log('======================================');


clFn.fn3();


let parent = function() {

}

parent.prototype = clFn.prototype;
parent.prototype.p1 = function() {
  console.log("call p1");
}


let p1 = new parent();
p1.p1();
p1.fn1();

console.log(clFn.prototype.constructor);
console.log(parent.prototype.constructor);
