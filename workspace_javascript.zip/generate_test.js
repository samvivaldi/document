function* generateSequence() {
    yield 1;
    yield 2;
    return 3;
  }


var generator = generateSequence();
console.log(generator); // [object Generator]

console.log(generator.next()); 
console.log(generator.next()); 
console.log(generator.next()); 
console.log(generator.next()); 
console.log(generator.next()); 


function* generateSequence() {
    yield 1;
    yield 2;
    yield 3;
  }
  
  var generator = generateSequence();
  
  for(let value of generator) {
    console.log(value); // 1, 2, 3
  }