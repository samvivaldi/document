import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CarNumCheck {

    public static void main(String[] args) {
        // 정규식 패턴을 String 배열에 저장
        String[] patterns = {
                "^[가-힣]{2}.[0-9]{1}.[가-힣].{1}.[0-94}$",
                "^[가-힣]{2}.[0-9]{2}.[가-힣].{1}.[0-9]{4}$",
                "^[0-9]{2}.[가-힣].{1}.[0-9]{4}$",
                "^[0-9]{3}.[가-힣].{1}.0-9]{4}$",
                "^[가-힣]{2}.[0-9]{3}.[가-힣].{1}.[0-9]{4}$",
                "^[가-힣]{2}.[0-9]{2}.[09]{4}$"
        };

        // 입력받은 문자열
        String input = "경기러1234";

        // 패턴에 대한 인덱스를 저장할 변수
        int index = -1;

        // 패턴 배열을 loop 돌면서 입력받은 문자열 비교
        for (int i = 0; i < patterns.length; i++) {
            Pattern p = Pattern.compile(patterns[i]);
            Matcher m = p.matcher(input);
            if (m.matches()) {
                index = i;
                break;
            }
        }

        // 일치하는 패턴이 있으면 해당 패턴의 인덱스를 출력
        if (index >= 0) {
            System.out.println("입력한 문자열은 " + (index + 1) + "번째 패턴과 일치.");
        } else {
            System.out.println("입력한 문자열은 유효한 패턴이 아닙니다.");
        }
    }
}