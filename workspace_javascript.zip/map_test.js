

let t = /to(?!ma)/;

let map = new Map();



map.set('1', 'str1');   // 문자형 키
map.set(1, 'num1');     // 숫자형 키
map.set(true, 'bool1'); // 불린형 키
map.set('a', 'aaaa');   // 문자형 키


console.log(map.get('1'));
console.log(map.get(1));
console.log(map.get(true));
console.log(map.get('2'));
console.log("map.has('a') : " + map.has('a'));

map.has()

console.log('map.delete(1):' + map.delete(1));


console.log( map.size ); // 3


for (let k of map.keys()) {
    console.log(`key ${k}`);
}

for (let v of map.values()) {
    console.log(`value ${v}`);
}

for (let e of map.entries()) {
    console.log(`entries ${e}`);
}

map.delete(true);

let obj = Object.fromEntries(map.entries()); // 맵을 일반 객체로 변환 (*)

console.log(map);
console.log(obj);

let map2 = new Map(Object.entries(obj));
console.log(map2 instanceof Map);

