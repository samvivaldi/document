

/*axa eslint-disable no-empty   axa*/
/*axa Modal창 처리 axa*/
/*axa 2021.06. 26 sam axa*/
window.axaModal_UniqTime = new Date();

window.AxaModal = {

    modal_focus_target: null,
    size: "1",
    postFormId: 'form3232325723234',
    maskDivId: 'div3232325723234',

    selectorTargetDoc: function () {

        let targetDoc = null;

        if (this.size == "1") {
            targetDoc = document.body;
        } else {
            try {
                targetDoc = parent.document.querySelector("#apFrameBody");
                if (!targetDoc) {
									targetDoc = document.body;
                }
            } catch (e) {
                targetDoc = document.body;
            }
        }
        return targetDoc;
    },

    /*axa 화면에 layer 덮어 쓰기  axa*/
    /*axa 2021.06. 25 sam  axa*/
    wrapMask: function () {

        this.unWrapMask();

        let maskDiv = document.createElement("DIV");
        maskDiv.id = this.maskDivId;

         /*axa let docHeight = document.body.scrollHeight; axa*/
        let docHeight = this.selectorTargetDoc().scrollHeight;

        /*axa maskDiv.style.cssText = "position: absolute; z-index: 100; background-color: gray; left: 0; top: 0; opacity: 0.3; width:100%; height:100%;";   axa*/
        maskDiv.style.cssText = "position: absolute; z-index: 100; background-color: gray; left: 0; top: 0; opacity: 0.3; width:100%; height:" + docHeight + "px;";

        /*axa document.body.append(maskDiv); ie11 에서 지원하지 않음.   axa*/
        this.selectorTargetDoc().appendChild(maskDiv);

        maskDiv.addEventListener('click', function () {

            if (this.selectorTargetDoc().querySelector("#" + this.maskDivId)) {
                try {
                    if (this.modal_focus_target) {
                        this.modal_focus_target.focus();
                    }
                } catch (error) {
                    console.log("AxaModal modal exception" + error);
                }
            }
        }.bind(this));

    },

     /*axa window.close 시 opner에 전체 layer 제거  axa*/
     /*axa 2021.06. 25 sam  axa*/
    unWrapMask: function () {
        let temp = this.selectorTargetDoc().querySelector("#" + this.maskDivId);
        if (temp) {
            if (temp.remove) {
            		/*axa    ie11 에서 지원하지 않음.   axa*/
                temp.remove();  
            } else {
                temp.removeNode();
            }
        }
       this.modal_focus_target = null;

    },


     /*axa window.open 시 화면에 layer 덮어 쓰고 window open 하기  axa*/
     /*axa 내부적으로 post 방식으로 변경해서 호출함.  axa*/
     /*axa 2021.06. 25 sam  axa*/
     /*axa urlValue : get방식의 url 또는 Array(기존모달창에서 사용하던) 형태의 param.push(['A', '/ActionControler.action?screenID=CTSC0013&actionID=S04', '']); param.push(['P', 'hidKeyType', oForm.hidKeyType.value]);  axa*/
     /*axa title : 필수값   axa*/
     /*axa shape : width=870px, height=600px, left=280px, top=300px, location=no...........   axa*/
     /*axa size : 1 일경우 해당 document, 2 일 경우 전체화면    axa*/
    open: function (urlValue, title, shape, size) {

        let targetUrl = null;

        this.size = "2";
        if (size) {
            this.size = size;
           
        }

        let target = title.replace(/\s|\.|-/g, "") + window.axaModal_UniqTime.getTime();

        if (urlValue instanceof Array) {
            targetUrl = this.makeURI(urlValue);
        } else {
            targetUrl = urlValue;
        }

        this.wrapMask();
      

        let tempForm = this.makeform(targetUrl, target);

        this.modal_focus_target = window.open("", target, shape);
        this.watchAliveWindow();

        document.body.appendChild(tempForm);
        tempForm.submit();

        try { document.getElementById(this.postFormId).remove(); } catch (e) { ;;; }

        /*axa  return this.modal_focus_target;  axa*/
        
        let promi = new Promise((resolve) => {
            const breakId = setInterval(() => {
                if (!this.modal_focus_target || this.modal_focus_target.closed) {
                clearInterval(breakId);
                resolve();
                }
            }, 500);
            });

        promi.close = () => {
                    try {
                        this.modal_focus_target.close();
                    } catch(e) {
                        ;;
                    }
            };

	    return promi;
    },



    /*axa Dom이 load되기 전에 강제 종료 할경우 체크해서 layer 지우기  axa*/
    watchAliveWindow: function () {

        let interId = null;
        try {
            interId = setInterval(function () {
                if (this.modal_focus_target == null || this.modal_focus_target.closed) {
                    clearInterval(interId);
                    this.unWrapMask();
                }
            }.bind(this), 500);
        } catch (e) {
            try {   clearInterval(interId);  } catch(e) { }
            try {   this.unWrapMask();       } catch(e) { }
        }
    },

    makeURI: function (oArray) {

        let strUri_1 = "";
        let strUri_2 = "";

        oArray.forEach(function (el) {
            if (el[0] == "A") {
                strUri_1 = el[1];
            } else {
                strUri_2 = strUri_2 + "&" + el[1] + "=" + el[2];
            }
        });

        return strUri_1 + strUri_2;
    },

    makeform: function (pUrl, target) {

        try { document.getElementById(this.postFormId).remove(); } catch (e) { ;;; }

        let postAction = pUrl.substring(0, pUrl.indexOf("?"));

        if (postAction == "") {
            postAction = pUrl;
        }

        let frmPopUp = document.createElement("form");
        frmPopUp.name = this.postFormId;
        frmPopUp.method = 'post';
        frmPopUp.action = postAction;
        frmPopUp.target = target;
        frmPopUp.id = this.postFormId;

        let arrParams = pUrl.substring(pUrl.indexOf("?") + 1).split("&");
        let hidKey = "";
        let hidValue = "";
        let screenIDVal = "";
        let actionIDVal = "";

        for (let i = 0; i < arrParams.length; i++) {
            if (arrParams[i].indexOf("=") < 0) {
                continue;
            } else {
                hidKey = arrParams[i].substring(0, arrParams[i].indexOf("="));
                hidValue = arrParams[i].substring(arrParams[i].indexOf("=") + 1);

                if (hidKey == "screenID") {
                    screenIDVal = hidValue;
                } else if (hidKey == "actionID") {
                    actionIDVal = hidValue;
                } else {
                    this.fnAddHidden(frmPopUp, hidKey, hidValue);
                }
            }
        }

        if (screenIDVal != '') {
            frmPopUp.action = postAction + "?screenID=" + screenIDVal + "&actionID=" + actionIDVal;
        } else {
            frmPopUp.action = postAction;
        }
        return frmPopUp;
    },

    fnAddHidden: function (pForm, pName, pValue) {
        let i = document.createElement("input");
        i.type = "hidden";
        i.name = pName;
        i.value = pValue;
        pForm.appendChild(i);
        return pForm;
    }

}

