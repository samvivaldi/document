async function fnTest() {
    console.log("start");

    let promise = await new Promise((resolve, reject) => { setTimeout(() => resolve(), 3000);    });
    // await promise;

    console.log("3초 대기후 출력");

}


async function fnTest2() {
    console.log('call fnTest2');

    await new Promise(res => setTimeout(() => res(), 5000));

    console.log('5555 call fnTest2');

}

fnTest2();

