from openpyxl import Workbook
from openpyxl.styles import Alignment, Font

# 워크북 생성
wb = Workbook()

# 워크시트 선택
ws =.active

# 워크시트 이름 변경
ws.title = "2023년 4월"

# 셀 스타일 지정
center_alignment = Alignment(horizontal="center", vertical="center")
bold_font = Font(bold=True)

# 헤더 셀 스타일 지정
ws.merge_cells("A1:G1")
ws["A1"].value = "2023 4월"
ws["A1"].font = bold_font
ws["A1"].alignment = center_alignment

# 요일 셀 스타일 지정
days_of_week = ["일", "월", "화", "수", "목", "금", "토"]
for i, day in enumerate(days_of_week):
    cell = ws.cell(row=2,=i+1)
    cell.value = day
    cell.font = bold_font
    cell.alignment = center_alignment

# 날짜 셀 스타일 지정
year = 2023
month = 4
days_in_month = 30
first_day = 2  # 2023년 4월 1일은 화요일
date = for i in range(3, 9):
            for j in range(1, 8):
                cell = ws.cell(row=i, column=j)
                    if i == 3 and j < first_day:
                        cell.value = ""
                    elif date > days_in_month:
                        cell.value = ""
                    else:
                        cell.value = date
                        date += 1
 cell.alignment = center_alignment

# 엑셀 파일 저장
wb.save("C:\Temp\AAAA.xlsx")