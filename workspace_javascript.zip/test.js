function formatPhoneNumber(input) {

    let phoneNumber = input.replace(/\D/g,'');

    let phoneNumberLength = phoneNumber.length;
    let formattedPhoneNumber = null;
      
    if (phoneNumberLength === 10) {
      formattedPhoneNumber = phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
    } else if (phoneNumberLength === 11) {
      formattedPhoneNumber = phoneNumber.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3');
    } else {
      return input;
    }
  
    return formattedPhoneNumber;
  } 
  
  function formatPhoneNumber2(input) {

    let phoneNumber = input.replace(/\D/g,'');
       
    let regexp = /(\d{3})(\d{3,4})(\d{4})/g;
    
    if (regexp.test(phoneNumber)) {

        console.log("exec result:", regexp.exec(phoneNumber));
        return phoneNumber.replace(regexp, "$1-$2-$3");
    } else {
        return input;
    }

  }   


let reg4 = /^(((?!google)).)*$/;

  let test1 =  '0101112222';
  let test2 =  '01011112222';
  let test3 =  '0101115555b';
  let test4 =  '010111223';

  console.log(formatPhoneNumber(test1));
  console.log(formatPhoneNumber(test2));
  console.log(formatPhoneNumber(test3));
  console.log(formatPhoneNumber(test4));

  console.log('-------------------');
  console.log(formatPhoneNumber2(test1));
  console.log(formatPhoneNumber2(test2));
  console.log(formatPhoneNumber2(test3));
  console.log(formatPhoneNumber2(test4));


  