let promise = new Promise((resolve, reject) => {
    //setTimeout(() => resolve("완료!"), 1000);
    setTimeout(() => reject(new Error("에러 발생!")), 1000)

    //resolve("완료!");
  }).catch(
    reject => console.log("bbbbbbbbbbbbbbbbb:" + reject)
  );
  
  // resolve 함수는 .then의 첫 번째 함수(인수)를 실행합니다.
promise.then(resolve => {
          console.log(resolve);
          return "0000000000";
      }, reject => {
         consolog.log("err1:" + reject);
      }
).then(resolve => console.log("then1_1 :" + resolve), reject=> console.log("err1_1 : " + reject));


promise.then(resolve => console.log("then2 :" + resolve), reject=> console.log("err2 : " + reject));
promise.then(resolve => console.log("then3 :" + resolve), reject=> console.log("err3 : " + reject));