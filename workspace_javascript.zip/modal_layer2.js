/**
 * Modal창 처리
 * 2021.06. 26 sam
 */

window.AxaModal = {

    modal_focus_target: null,
    size: "1",
    postFormId: 'form3232325723234',
    maskDivId: 'div3232325723234',

    selectorTargetDoc: function () {

        let targetDoc = null;

        if (this.size == "1") {
            targetDoc = document.body;
        } else {
            try {
                targetDoc = parent.document.querySelector("#apFrameBody");
            } catch (e) {
                targetDoc = document.body;
            }
        }
        return targetDoc;
    },

    /**
     * 화면에 layer 덮어 쓰기 
     * 2021.06. 25 sam
     */
    wrapMask: function () {

        this.unWrapMask();

        let maskDiv = document.createElement("DIV");
        maskDiv.id = this.maskDivId;
        maskDiv.style.cssText = "position: absolute; z-index: 100; background-color: gray; left: 0; top: 0; opacity: 0.3; width:100%; height:100%;";
        ////document.body.append(maskDiv); ie11 에서 지원하지 않음. 
        this.selectorTargetDoc().appendChild(maskDiv);

        maskDiv.addEventListener('click', function () {

            if (this.selectorTargetDoc().querySelector("#" + this.maskDivId)) {
                try {
                    if (this.modal_focus_target) {
                        this.modal_focus_target.focus();
                    }
                } catch (error) {
                    console.log("AxaModal modal exception" + error);
                }
            }
        }.bind(this));

    },

    /**
     * window.close 시 opner에 전체 layer 제거
     * 2021.06. 25 sam
     */
    unWrapMask: function () {
        let temp = this.selectorTargetDoc().querySelector("#" + this.maskDivId);
        if (temp) {
            if (temp.remove) {
                temp.remove(); // ie11 에서 지원하지 않음. 	
            } else {
                temp.removeNode();
            }
        }

    },

    /**
     * window.open 시 화면에 layer 덮어 쓰고 window open 하기
     * 내부적으로 post 방식으로 변경해서 호출함.
     * 2021.06. 25 sam
     * urlValue : get방식의 url 또는 Array(기존모달창에서 사용하던) 형태의 param.push(['A', '/ActionControler.action?screenID=CTSC0013&actionID=S04', '']); param.push(['P', 'hidKeyType', oForm.hidKeyType.value]);
     * title : 필수값
     * shape : width=870px, height=600px, left=280px, top=300px, location=no...........
     * size : 1 일경우 해당 프레임, 2 일 경우 전체화면
     */
    open: function (urlValue, title, shape, size) {

        let targetUrl = null;

        this.size = "1";
        if (size) {
            this.size = size;
        }

        let target = title.replace(/\s|\.|-/g, "");

        try {
            target = target + openSessionID;
        } catch(e) {
            console.log("openSessionID 변수를 찾을수 없습니다");
        }

        if (urlValue instanceof Array) {
            targetUrl = this.makeURI(urlValue);
        } else {
            targetUrl = urlValue;
        }

        this.wrapMask();

        let tempForm = this.makeform(targetUrl, target);

        this.modal_focus_target = window.open("", target, shape);
        this.watchAliveWindow();

        document.body.appendChild(tempForm);
        tempForm.submit();

        try { document.getElementById(this.postFormId).remove(); } catch (e) { ;;; }

        return new Promise((resolve) => {
            const intervalId = setInterval(() => {
              if (this.modal_focus_target && this.modal_focus_target.closed) {
                clearInterval(intervalId);
                resolve();
              }
            }, 500);
          });

    },

    /**
     * Dom이 load되기 전에 강제 종료 할경우 체크해서 layer 지우기 
     */
    watchAliveWindow: function () {
        let interId = setInterval(function () {
            if (this.modal_focus_target.closed) {
                clearInterval(interId);
                this.unWrapMask();
            }
            console.log("watching AliveWindow");
        }.bind(this), 500);
    },

    makeURI: function (oArray) {

        let strUri_1 = "";
        let strUri_2 = "";

        oArray.forEach(function (el) {
            if (el[0] == "A") {
                strUri_1 = el[1];
            } else {
                strUri_2 = strUri_2 + "&" + el[1] + "=" + el[2];
            }
        });

        return strUri_1 + strUri_2;
    },

    makeform: function (pUrl, target) {

        try { document.getElementById(this.postFormId).remove(); } catch (e) { ;;; }

        let postAction = pUrl.substring(0, pUrl.indexOf("?"));

        if (postAction == "") {
            postAction = pUrl;
        }

        let frmPopUp = document.createElement("form");
        frmPopUp.name = this.postFormId;
        frmPopUp.method = 'get';
        frmPopUp.action = postAction;
        frmPopUp.target = target;
        frmPopUp.id = this.postFormId;

        let arrParams = pUrl.substring(pUrl.indexOf("?") + 1).split("&");
        let hidKey = "";
        let hidValue = "";
        let screenIDVal = "";
        let actionIDVal = "";

        for (let i = 0; i < arrParams.length; i++) {
            if (arrParams[i].indexOf("=") < 0) {
                continue;
            } else {
                hidKey = arrParams[i].substring(0, arrParams[i].indexOf("="));
                hidValue = arrParams[i].substring(arrParams[i].indexOf("=") + 1);

                if (hidKey == "screenID") {
                    screenIDVal = hidValue;
                } else if (hidKey == "actionID") {
                    actionIDVal = hidValue;
                } else {
                    this.fnAddHidden(frmPopUp, hidKey, hidValue);
                }
            }
        }

        if (screenIDVal != '') {
            frmPopUp.action = postAction + "?screenID=" + screenIDVal + "&actionID=" + actionIDVal;
        } else {
            frmPopUp.action = postAction;
        }
        return frmPopUp;
    },

    fnAddHidden: function (pForm, pName, pValue) {
        let i = document.createElement("input");
        i.type = "hidden";
        i.name = pName;
        i.value = pValue;
        pForm.appendChild(i);
        return pForm;
    }
}



