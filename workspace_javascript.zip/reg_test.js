let str1 = `aaa<p1>ddd</p1>ddd`;


console.log(str1);


let reg = /<p(\d)>.*<\/p\1>/g;

let result = reg.exec(str1);

console.log(result);

console.log(reg.test(str1));

//let reg2 = /(?=(\d{3})+(?!\d))/g;



let reg2 = /\B(?=(\d{3})+(?!\d))/g;
let str2 = "12345678";

let result2 = str2.replace(reg2,',');

console.log(result2);

let reg3 = /^((?!만세).)*$/;

