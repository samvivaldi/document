let promise = new Promise((resolve, reject) => {
    setTimeout(() => resolve("완료!"), 1000);
    // setTimeout(() => reject(new Error("에러 발생!")), 1000)
    //setTimeout(() => reject('EEEEEEEEEEEE'), 1000)

    // resolve("완료a!");
  });
  
  // resolve 함수는 .then의 첫 번째 함수(인수)를 실행합니다.
promise.then(
             aaa => console.log(aaa), // 1초 후 "완료!"를 출력
           //  error => console.log(error) // 실행되지 않음
          
        ).catch(error => console.log("aaa:" + error));


promise.then(resolve => console.log("then2 :" + resolve), reject=> console.log("err2 : " + reject));
promise.then(resolve => console.log("then3 :" + resolve), reject=> console.log("err3 : " + reject));

3334343