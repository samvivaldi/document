async function f() {

  let promise = new Promise((resolve, reject) => {
    setTimeout(() => resolve("완료!"), 1000)
  });

  let result =  await promise; // 프라미스가 이행될 때까지 기다림 (*)

  console.log(result); // "완료!"
  console.log("222222222222222222");
}

f();


async function fn2(miliSec) {
  console.log("AAAAAAAAAAAAA");
  let promise = new Promise((resolve, reject) => { setTimeout(()=> resolve("."), miliSec) });
  await promise;

  console.log("BBBBBBBBBBBBB");

}


fn2(3000);
