import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/*
 * 방식: AES256/CBC
 * 패딩: PKCS#7
 * 인코딩: BASE64 (charset=UTF8)
 */
public class AES256CBC {

    private static final String ALGORITHM = "AES/CBC/PKCS5Padding";
    private static final String CHARSET = "UTF-8";
    static final String KEY = "0123456789abcdef0123456789abcdef";
    private static final String IV = "0123456789abcdef";

    public static String encrypt(String data) throws Exception {
        byte[] keyBytes = KEY.getBytes(StandardCharsets.UTF_8);
        byte[] ivBytes = IV.getBytes(StandardCharsets.UTF_8);
        SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
        byte[] encrypted = cipher.doFinal(data.getBytes(CHARSET));
        return Base64.getEncoder().encodeToString(encrypted);
    }

    public static String decrypt(String encryptedData) throws Exception {
        byte[] keyBytes = KEY.getBytes(StandardCharsets.UTF_8);
        byte[] ivBytes = IV.getBytes(StandardCharsets.UTF_8);
        SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
        byte[] decrypted = cipher.doFinal(Base64.getDecoder().decode(encryptedData));
        return new String(decrypted, CHARSET);
    }

    public static void main(String[] args) throws Exception {
        String data = "암호화할 데이터";
        String encrypted = AES256CBC.encrypt(data);
        System.out.println("암호화된 데이터: " + encrypted);
        String decrypted = AES256CBC.decrypt(encrypted);
        System.out.println("복호화된 데이터: " + decrypted);
    }
}