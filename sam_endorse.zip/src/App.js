import './App.css';
import EndorseList from './endorsement/EndorseList';
import { Route, Switch } from 'react-router-dom';
import ContractInfo from './contractInfo/ContractInfo';

function App() {
  return (
    <div>
      <Switch>
        <Route path={['/', '/endorseList']} component={EndorseList} exact={true} />
        <Route path='/contractInfo' component={ContractInfo} />

      </Switch>
    </div>

  );
}

export default App;
