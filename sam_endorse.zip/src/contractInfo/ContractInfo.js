import React, { Component } from "react";

class ContractInfo extends Component {
    render() {
        return <div>
            ContractInfo

            <button onClick={() => { this.props.history.goBack() }}>뒤로</button>

        </div>
    }

}

export default ContractInfo;
