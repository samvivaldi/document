import React, { Component, Fragment } from "react";
import { Link } from "react-router-dom";

class EndorseListRecord extends Component {
  render() {
    const scroll = {
      width: "822",
      height: "323",
      overflow: "auto",
      padding: "0px 0px",
      border: "0px",
    };
    const talbeFixed = {
      tableLayout: "fixed",
    };

    let { records } = this.props;

    if (!records) {
      records = [];
    }

    return (

      <div>
        <table width="805" border="0" cellSpacing="0" cellPadding="0">
          <tbody>
            <tr>
              <td width="230" height="10">
                <div align="left">조회건수 : {records.length}건</div>
              </td>
            </tr>
          </tbody>
        </table>
        <table
          width="805"
          border="0"
          cellPadding="0"
          cellSpacing="0"
          className="line-table2"
          style={talbeFixed}
        >
          <tbody>
            <tr>
              <th width="108" className="header_line">
                피보험자명
              </th>
              <th width="108" className="header_line">
                피보험자코드
              </th>
              <th width="136" className="header_line">
                차량번호
              </th>
              <th width="84" className="header_line">
                증권번호
              </th>
              <th width="84" className="header_line">
                설계번호
              </th>
              <th width="110" className="header_line">
                설계자
              </th>
              <th width="109" className="header_line">
                상태구분
              </th>
              <th width="65" className="header_line">
                승인자
              </th>
            </tr>
            <tr align="center">
              <th colSpan="2" className="databg_line" width="216">
                배서사유
              </th>
              <th width="136" className="databg_line">
                배서보험료
              </th>
              <th width="168" colSpan="2" className="databg_line">
                배서처리구분
              </th>
              <th width="110" className="databg_line">
                서류제출
              </th>
              <th width="109" className="databg_line">
                설계일자
              </th>
              <th width="65" className="databg_line">
                배서확정일
              </th>
            </tr>
          </tbody>
        </table>
        <div style={scroll}>
          <table
            width="805"
            border="0"
            cellPadding="0"
            cellSpacing="0"
            className="table6-free"
            style={talbeFixed}
          >
            <tbody>

              {records.map(record => (
                <Fragment key={record.endrs_no} >
                  <tr align="center" className="header_line">
                    <td width="108">{record.insrd_nm}</td>
                    <td width="108">{record.insrd_cd}</td>
                    <td width="136" colSpan="2">{record.car_no}</td>
                    <td width="84">
                      <Link to="/contractInfo">{record.policy_no}</Link>
                    </td>
                    <td width="84">{record.endrs_no}</td>
                    <td width="55">{record.input_emp_no}</td>
                    <td width="56">{record.input_emp_no_nm}</td>
                    <td width="109">{record.strStatNm}</td>
                    <td width="65">{record.strAprvPrcsEmpNo}</td>
                  </tr>
                  <tr align="center" className='header_line'>
                    <td colSpan="2" width="216"  >{record.endrs_cd}</td>
                    <td width="68" >{record.sup_chrg_rfnd_type}</td>
                    <td width="68" align="right">{record.sup_chrg_rfnd_insrfee}원</td>
                    <td colSpan="2" width="168" align="cneter">{record.endrs_prcs_type}</td>
                    <td></td>
                    <td>

                    </td>
                    <td>{record.input_dt}</td>
                    <td>{record.endrs_cnfm_dt}</td>
                  </tr>
                </Fragment>

              ))}


            </tbody>
          </table>
        </div>
      </div >
    );
  }
}

export default EndorseListRecord;
