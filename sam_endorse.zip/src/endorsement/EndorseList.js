import React, { Component } from "react";
import { Link } from "react-router-dom";
import EndorseHead from "./EndorseHead";
import EndorseSearchComboT from "./EndorseSearchComboT";
import EndorseListRecord from "./EndorseListRecord";
import "../sam_test.css";
import axios from 'axios';


class EndorseList extends Component {


  constructor(props) {
    super(props);
    this.state = {};

  }

  fnsubmit = (params) => {
    console.log('EndorseList fnsubmit call', params);

    if (!params['txtStartDt'] || params['txtStartDt'].length !== 8) {
      alert('조회기간을 입력하여 주세요');
      return;
    }

    const url = "http://localhost:15000/endorse";

    axios.get(url, params)
      //axios.get(url, { params, responseEncoding: "euc-kr" })
      .then((res) => {
        console.log(res);
        this.setState({ records: res.data });
      })
      .catch((error) => {
        console.log(error.response)
      })


  }

  render() {
    return (
      <div>
        <EndorseHead></EndorseHead>
        <EndorseSearchComboT fnsubmit={this.fnsubmit}></EndorseSearchComboT>
        <br></br>
        <EndorseListRecord records={this.state.records}></EndorseListRecord>

        <ul>
          <li>
            <Link to="/contractInfo">계약조회</Link>
          </li>
        </ul>
      </div>
    );
  }
}

export default EndorseList;
