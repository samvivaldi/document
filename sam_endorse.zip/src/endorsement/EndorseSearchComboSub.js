import React, { Component } from 'react';


class EndorseSearchComboSub extends Component {

    constructor(props) {
        super(props);
        this.state = { lstEndrsStat1: '0' };
    }


    render() {
        const styleImeMod = {
            imeMmode: 'disabled'
        };
        return (
            <div style={{ float: 'left' }}>
                <select name="lstEndrsStat1" className="select" style={styleImeMod}
                    onChange={(e) => {
                        this.props.changeVal(e.target.value);
                    }
                    }>
                    <option value="0" >전체</option>
                    <option value="1">설계중</option>
                    <option value="2">설계완료</option>
                    <option value="3">수납대기</option>
                    <option value="4">배서확정</option>
                </select>
            </div>
        );
    }
}

export default EndorseSearchComboSub;
