import React, { Component } from 'react';
import { Icon } from 'semantic-ui-react'

class EndorseHead extends Component {
    render() {
        return (
            <div>
                <table width="805" border="0" cellSpacing="0" cellPadding="0">
                    <tbody>
                        <tr>
                            <td width="484" height="10">
                                <div align="left">
                                    <span className="tit"> <Icon name='list' />자동차 배서설계건 조회</span></div>
                            </td>

                        </tr>
                    </tbody>
                </table>
            </div>
        );
    }
}

export default EndorseHead;