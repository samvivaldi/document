import React, { Component } from 'react';

class EndorseSearchComboSub2 extends Component {

    handleChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        });
        console.log(this.state);
    }

    render() {

        const { lstEndrsStat2 } = this.props;

        let contents = null;

        if (lstEndrsStat2 === "0") {
            contents = [
                { id: 0, title: "전체" },
            ];
        } else if (lstEndrsStat2 === "1") {
            contents = [
                { id: 1, title: "설계중" },
            ];
        } else if (lstEndrsStat2 === "2") {
            contents = [
                { id: 26, title: "조건부불가" },
                { id: 20, title: "전체" },
                { id: 21, title: "확정가능" },
                { id: 22, title: "심의대상" },
                { id: 24, title: "승인" },
                { id: 25, title: "불가" },
            ];
        } else if (lstEndrsStat2 === "3") {
            contents = [
                { id: 30, title: "수납대기" },
            ];
        } else if (lstEndrsStat2 === "4") {
            contents = [
                { id: 41, title: "배서확정" },
            ];
        } else {
            contents = [];
        }

        return (
            <div>
                <select name="lstEndrsStat2" style={{ width: "130px" }} onChange={(e) => {
                    this.props.changeVal(e.target.value);
                }
                }>

                    {contents.map((cont) => (
                        <option key={cont.id} value={cont.id}>
                            {cont.title}
                        </option>
                    ))}
                </select>
            </div>
        );
    }
}

export default EndorseSearchComboSub2;