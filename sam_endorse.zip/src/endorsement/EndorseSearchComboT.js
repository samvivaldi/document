import React, { Component } from 'react';
import { fnAddDatePoint, fnDelDatePoint, fnOnlyNumberInput } from '../common/SamUtil'
import EndorseSearchComboSub from './EndorseSearchComboSub'
import EndorseSearchComboSub2 from './EndorseSearchComboSub2'
import { Icon, Button } from 'semantic-ui-react'

class EndorseSearchComboT extends Component {

    constructor(props) {
        super(props);
        this.state = {
            lstEndrsStat1: '0',
            lstEndrsStat2: '0',
            lstDtStat: '1',
            searchInsrType: '2'
        };
    }

    handleChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        });

    }

    fnsubmit = (e) => {
        this.props.fnsubmit(this.state);
    }

    render() {
        const styleImeMod = {
            imeMmode: 'disabled'
        };

        return (
            <div>
                <table width="805" border="0" cellPadding="0" cellSpacing="0" className="line-table3">
                    <tbody>
                        <tr>
                            <th width="70" height="25">조회기간 </th>
                            <td>
                                <select name="lstDtStat" className="select" style={{ width: '110px' }} onChange={this.handleChange}>
                                    <option value="1">배서설계일</option>
                                    <option value="2">배서확정일</option>
                                </select>

                                <input name="txtStartDt" type="text" size="8" maxLength='8' style={styleImeMod} data-kinds='1'
                                    onChange={this.handleChange} onBlur={fnAddDatePoint} onFocus={fnDelDatePoint} onKeyDown={fnOnlyNumberInput.bind(this, '1')}
                                />
								~
								<input name="txtEndDt" type="text" size="8" maxLength='8' style={styleImeMod}
                                    onChange={this.handleChange} onBlur={fnAddDatePoint} onFocus={fnDelDatePoint} onKeyDown={fnOnlyNumberInput.bind(this, '1')}
                                /></td>
                            <th width="60">조회대상</th>
                            <td width='250'>
                                <EndorseSearchComboSub changeVal={(val) => { this.setState({ lstEndrsStat1: val }) }}></EndorseSearchComboSub>
                                <EndorseSearchComboSub2 changeVal={(val) => { this.setState({ lstEndrsStat2: val }) }} lstEndrsStat2={this.state.lstEndrsStat1}></EndorseSearchComboSub2>
                            </td>
                            <th width="60">설계자</th>
                            <td><input type="text" name="txtInputEmpNo" size="7" style={styleImeMod} />
                            </td>
                        </tr>
                    </tbody>
                </table>
                <table width="805" border="0" cellPadding="0" cellSpacing="0" className="table3">
                    <tbody>
                        <tr>
                            <th width='70' rowSpan="2">조회기준<br />추가
                        </th>
                            <td width="110" className="header_line6">
                                <select name="searchInsrType" className="select" style={{ width: '110px' }} onChange={this.handleChange}>
                                    <option value="2">피보험자고객ID</option>
                                    <option value="1">피보험자코드</option>
                                </select>

                            </td>
                            <td width="420"><input type="text" name="txtInsrdCd" size="16" style={{ width: '110px' }} maxLength='15'
                                onChange={this.handleChange} />
                                <input name="txtInsrdNm" type="text" className="input2" size="25" />
                            </td>
                            <td width='80' className="header_line6">차량번호</td>
                            <td><input type="text" name="txtCarNo" size="16" onChange={this.handleChange} /></td>
                        </tr>
                        <tr>
                            <td className="header_line6">설계번호</td>
                            <td><input type="text" name="txtEndrsNo" size="16" style={{ width: '110px' }}
                                maxLength='13' onChange={this.handleChange} /></td>
                            <td className="header_line6">증권번호</td>
                            <td><input type="text" name="txtPolicyNo" size="16" style={{ width: '110px' }} maxLength='12'
                                onChange={this.handleChange} /></td>
                        </tr>
                    </tbody>
                </table>

                <table width="805" border="0" cellSpacing="0" cellPadding="0">
                    <tbody>
                        <tr>
                            <td height="25" align="right" onClick={this.fnsubmit}>
                                <Button size='mini' color='blue'><Icon name='search' />조회</Button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div >
        );
    }

}


export default EndorseSearchComboT;

