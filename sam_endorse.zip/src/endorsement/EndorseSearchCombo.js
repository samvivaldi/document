import React, { Component } from 'react';
import { fnAddDatePoint, fnDelDatePoint, fnOnlyNumberInput } from '../common/SamUtil'
import EndorseSearchComboSub from './EndorseSearchComboSub'
import EndorseSearchComboSub2 from './EndorseSearchComboSub2'

class EndorseSearchCombo extends Component {

	constructor(props) {
		super(props);
		this.state = {
			lstEndrsStat1: '0',
			lstEndrsStat2: '0'
		};
	}

	handleChange = (e) => {
		this.setState({
			[e.target.name]: e.target.value
		});
		console.log("aaa", this.state);
	}

	render() {
		const styleImeMod = {
			imeMmode: 'disabled'
		};

		return (
			<div>
				<table width="805" border="0" cellPadding="0" cellSpacing="0" className="line-table3">
					<tbody>
						<tr>
							<th width="70" height="25">조회기간 </th>
							<td>
								<select name="lstDtStat" className="select" style={{ width: '110px' }} onChange={this.handleChange}>
									<option value="1">배서설계일</option>
									<option value="2">배서확정일</option>
								</select>

								<input name="txtStartDt" type="text" size="8" maxLength='8' style={styleImeMod} data-kinds='1'
									onChange={this.handleChange} onBlur={fnAddDatePoint} onFocus={fnDelDatePoint} onKeyDown={fnOnlyNumberInput.bind(this, '1')}
								/>
								~
								<input name="txtEndDt" type="text" size="8" maxLength='8' style={styleImeMod}
									onChange={this.handleChange} onBlur={fnAddDatePoint} onFocus={fnDelDatePoint} onKeyDown={fnOnlyNumberInput.bind(this, '1')}
								/></td>
							<th width="60">조회대상</th>
							<td width='250'>
								<EndorseSearchComboSub changeVal={(val) => { this.setState({ lstEndrsStat1: val }) }}></EndorseSearchComboSub>
								<EndorseSearchComboSub2 changeVal={(val) => { this.setState({ lstEndrsStat2: val }) }} lstEndrsStat2={this.state.lstEndrsStat1}></EndorseSearchComboSub2>
							</td>
							<th width="60">설계자</th>
							<td><input type="text" name="txtInputEmpNo" size="7" style={styleImeMod} />
							</td>
						</tr>
					</tbody>
				</table>
			</div >
		);
	}

}


export default EndorseSearchCombo;

