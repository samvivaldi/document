import React, { Component } from 'react';
import { Icon, Button } from 'semantic-ui-react'


class EndorseSearchCombo2 extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }


    fnsubmit = (e) => {

        console.log("EndorseSearchCombo2 fnsubmit");
        console.log(this.state);
        this.props.fnsubmit(this.state);

    }

    handleChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        });
    }

    render() {

        return (
            <div>
                <table width="805" border="0" cellPadding="0" cellSpacing="0" className="table3">
                    <tbody>
                        <tr>
                            <th width='70' rowSpan="2">조회기준<br />추가
                        </th>
                            <td width="110" className="header_line6">
                                <select name="searchInsrType" className="select" style={{ width: '110px' }} onChange={this.handleChange}>
                                    <option value="2">피보험자고객ID</option>
                                    <option value="1">피보험자코드</option>
                                </select>

                            </td>
                            <td width="420"><input type="text" name="txtInsrdCd" size="16" style={{ width: '110px' }} maxLength='15'
                                onChange={this.handleChange} />
                                <input name="txtInsrdNm" type="text" className="input2" size="25" />
                            </td>
                            <td width='80' className="header_line6">차량번호</td>
                            <td><input type="text" name="txtCarNo" size="16" onChange={this.handleChange} /></td>
                        </tr>
                        <tr>
                            <td className="header_line6">설계번호</td>
                            <td><input type="text" name="txtEndrsNo" size="16" style={{ width: '110px' }}
                                maxLength='13' onChange={this.handleChange} /></td>
                            <td className="header_line6">증권번호</td>
                            <td><input type="text" name="txtPolicyNo" size="16" style={{ width: '110px' }} maxLength='12'
                                onChange={this.handleChange} /></td>
                        </tr>
                    </tbody>
                </table>

                <table width="805" border="0" cellSpacing="0" cellPadding="0">
                    <tbody>
                        <tr>
                            <td height="25" align="right" onClick={this.fnsubmit}>
                                <Button size='mini' color='blue'><Icon name='search' />조회</Button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        );
    }
}

export default EndorseSearchCombo2;