export function fnAddDatePoint(e) {

    let oDate = e.target;
    let strMakeDate = "";
    if (oDate.value.length < 8) return;

    if (oDate.value.length === 8) {
        strMakeDate = oDate.value.substring(0, 4);
        strMakeDate += ".";
        strMakeDate += oDate.value.substring(4, 6);
        strMakeDate += ".";
        strMakeDate += oDate.value.substring(6, 8);
    } else {

        let cValue = "";
        for (let x = 0; x < oDate.value.length; x++) {
            cValue = oDate.value.substring(x, x + 1);
            if (cValue === ".")
                return;
        }

        strMakeDate += oDate.value.substring(0, 4);
        strMakeDate += ".";
        strMakeDate += oDate.value.substring(4, 6);
        strMakeDate += ".";
        strMakeDate += oDate.value.substring(6, 8);
    }
    oDate.value = strMakeDate;
    return;

}


export function fnDelDatePoint(e) {

    let oDate = e.target;

    let x;
    let cValue;
    let strTarget = "";
    if (oDate.value.length !== 10) return;

    for (x = 0; x < oDate.value.length; x++) {
        cValue = oDate.value.substring(x, x + 1);

        if (cValue !== ".") strTarget += cValue;
    }

    oDate.value = strTarget;
    return oDate;
}

export function fnOnlyNumberInput(strType, e) {

    let code = window.event.keyCode;


    if (strType === "1") {

        if ((code > 34 && code < 41) || (code > 47 && code < 58) || (code > 95 && code < 106)
            || code === 8 || code === 9 || code === 13 || code === 46 || (e.ctrlKey && code === 67)
            || (e.ctrlKey && code === 86) || (e.ctrlKey && code === 88)) {

            window.event.returnValue = true;
            return;
        }
        window.event.returnValue = false;
    } else if (strType === "2") {

        if ((code > 34 && code < 41) || (code > 47 && code < 58) || (code > 95 && code < 106)
            || code === 8 || code === 9 || code === 13 || code === 46 || code === 190 || code === 110
            || (e.ctrlKey && code === 67) || (e.ctrlKey && code === 86)
            || (e.ctrlKey && code === 88)) {

            window.event.returnValue = true;
            return;
        }
        window.event.returnValue = false;
    } else if (strType === "3") {

        if ((code > 34 && code < 41) || (code > 47 && code < 58) || (code > 95 && code < 106)
            || code === 8 || code === 9 || code === 13 || code === 46 || code === 189
            || code === 109 || (e.ctrlKey && code === 67) || (e.ctrlKey && code === 86)
            || (e.ctrlKey && code === 88)) {

            window.event.returnValue = true;
            return;
        }
        window.event.returnValue = false;
    } else if (strType === "4") {

        if ((code > 34 && code < 41) || (code > 47 && code < 58) || (code > 95 && code < 106)
            || code === 8 || code === 9 || code === 13 || code === 46
            || code === 190 || code === 110 || code === 189 || code === 109
            || (e.ctrlKey && code === 67) || (e.ctrlKey && code === 86)
            || (e.ctrlKey && code === 88)) {

            window.event.returnValue = true;
            return;
        }
    }

    window.event.returnValue = false;
}